"""Esquema inicial: códigos, historial y escaneos agregados.

Revision ID: 0001
"""

import sqlalchemy as sa
from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "links",
        sa.Column("code", sa.String(10), primary_key=True),
        sa.Column("destination", sa.Text(), nullable=True),
        sa.Column("status", sa.String(10), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "link_events",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("code", sa.String(10), sa.ForeignKey("links.code"), nullable=False),
        sa.Column("kind", sa.String(20), nullable=False),
        sa.Column("previous", sa.Text(), nullable=True),
        sa.Column("current", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_link_events_code", "link_events", ["code"])
    op.create_table(
        "scan_daily",
        sa.Column("code", sa.String(10), sa.ForeignKey("links.code"), primary_key=True),
        sa.Column("day", sa.Date(), primary_key=True),
        sa.Column("device", sa.String(10), primary_key=True),
        sa.Column("count", sa.Integer(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("scan_daily")
    op.drop_index("ix_link_events_code", "link_events")
    op.drop_table("link_events")
    op.drop_table("links")
