"""Entorno de Alembic. Las migraciones se ejecutan desde el código (studio.db.run_migrations)."""

from alembic import context

from studio.models import Base

connection = context.config.attributes["connection"]
context.configure(connection=connection, target_metadata=Base.metadata, render_as_batch=True)
with context.begin_transaction():
    context.run_migrations()
